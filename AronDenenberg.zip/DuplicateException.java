class DuplicateException extends Exception {}
